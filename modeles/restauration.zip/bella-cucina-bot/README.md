# 🍽️ Bella Cucina RP — Bot Discord + Dashboard

Bot Discord.js v14 + site web Express pour entreprise GTA RP restauration.

---

## 🚀 Déploiement sur Railway (étape par étape)

### 1. Préparer le dépôt Git

```bash
git init
git add .
git commit -m "init bella cucina rp"
git remote add origin https://github.com/TON_USER/bella-cucina-bot.git
git push -u origin main
```

### 2. Créer le projet Railway

1. Va sur [railway.app](https://railway.app) → **New Project**
2. Clique **Deploy from GitHub repo**
3. Sélectionne ton repo `bella-cucina-bot`
4. Railway détecte automatiquement Node.js via `nixpacks.toml`

### 3. Variables d'environnement Railway

Dans Railway → ton service → onglet **Variables**, ajoute :

| Variable | Valeur |
|---|---|
| `DISCORD_TOKEN` | Token de ton bot (Discord Developer Portal) |
| `DISCORD_CLIENT_ID` | Client ID du bot |
| `GUILD_ID` | ID de ton serveur Discord |
| `CHANNEL_CV` | ID du channel où arrivent les CV |
| `CHANNEL_LOGS` | ID du channel de logs |
| `CHANNEL_WELCOME` | ID du channel welcome |
| `CHANNEL_PRODUCTIONS` | ID du channel productions |
| `CHANNEL_VENTES` | ID du channel ventes |
| `CHANNEL_ALERTES` | ID du channel alertes |
| `ROLE_EMPLOYE` | ID du rôle Employé |
| `ROLE_ATTENTE_ENTRETIEN` | ID du rôle attente entretien |
| `ROLE_PATRON` | ID du rôle Patron |
| `ENTREPRISE_NOM` | Bella Cucina RP |
| `ENTREPRISE_COULEUR` | #C9A84C |
| `ENTREPRISE_EMOJI` | 🍽️ |
| `SESSION_SECRET` | une_chaine_aléatoire_longue |
| `WEB_URL` | https://ton-app.railway.app |

> Railway injecte `PORT` automatiquement — ne le configure pas.

### 4. Déployer les commandes slash Discord (1 seule fois)

```bash
# En local, avec .env rempli :
npm run deploy-commands
```

### 5. Volume persistant Railway (pour la DB + uploads)

SQLite et les uploads sont dans `/data/`. Pour persister entre les redémarrages :

1. Railway → ton service → onglet **Volumes**
2. **Add Volume** → Mount path : `/app/data`
3. Redéploie

### 6. Accéder au dashboard

- URL Railway (onglet **Settings → Networking → Public URL**)
- Connexion patron : crée ton mot de passe au premier accès
- Connexion employé : ID Discord + mot de passe créé au 1er login

---

## 📁 Structure du projet

```
bella-cucina-bot/
├── src/
│   ├── index.js              # Point d'entrée
│   ├── bot/
│   │   ├── client.js         # Client Discord
│   │   ├── deploy-commands.js
│   │   ├── commands/
│   │   │   ├── cv.js         # /cv — candidature
│   │   │   └── production.js # /production produire|vendre
│   │   └── events/
│   │       ├── buttonHandler.js
│   │       └── modalHandler.js
│   ├── web/
│   │   ├── server.js         # Express
│   │   └── routes/
│   │       ├── auth.js       # Login/logout
│   │       ├── patron.js     # Dashboard patron
│   │       ├── employe.js    # Dashboard employé
│   │       └── config.js     # Config bot
│   └── db/
│       └── database.js       # SQLite init
├── public/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
├── data/                     # .gitignore — créé au runtime
│   ├── bella.db              # SQLite
│   └── uploads/              # Captures d'écran
├── railway.json
├── nixpacks.toml
├── .env.example
└── package.json
```

---

## 🤖 Commandes Discord

| Commande | Description |
|---|---|
| `/cv` | Ouvre le formulaire de candidature (modal) |
| `/production produire` | Déclarer une production + preuve image |
| `/production vendre` | Déclarer une vente + preuve image |

---

## 🔄 Dupliquer pour une autre entreprise

1. Fork / clone le repo
2. Crée un **nouveau projet Railway** avec le nouveau repo
3. Configure les variables d'env pour le nouveau guild/entreprise
4. Crée un nouveau bot sur Discord Developer Portal
5. Lance `npm run deploy-commands` avec les nouvelles variables

Chaque instance = son propre bot, sa propre DB, son propre site.
