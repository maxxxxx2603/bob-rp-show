const api  = async (u,o={}) => (await fetch(u,{headers:{'Content-Type':'application/json'},credentials:'same-origin',...o})).json()
const post = (u,b) => api(u,{method:'POST',body:JSON.stringify(b)})
const el   = id => document.getElementById(id)
const fmt  = n  => Number(n||0).toLocaleString('fr-FR')
const fmtD = s  => s ? new Date(s).toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'2-digit'}) : '—'
const fmtH = m  => { const h=Math.floor(m/60),mn=m%60; return h?`${h}h${mn.toString().padStart(2,'0')}`:`${mn}min` }
const SLUG = location.pathname.split('/e/')[1]?.split('/')[0]||''
let _empId='', _timer=null, _serviceDebut=null, _couleur='#C9A84C'

// ── LOGIN ──────────────────────────────────────────────────────
async function initPage() {
  if (!SLUG) return showDead('URL invalide')
  const me = await api('/api/auth/me').catch(()=>({}))
  if (me.role==='employe') { launchApp(); return }
  const emp = await api(`/api/employe/slug/${SLUG}`)
  if (emp.error) return showDead('Espace introuvable')
  el('l-initiales').textContent = emp.avatar_initiales || emp.discord_tag?.slice(0,2).toUpperCase()||'RP'
  el('l-tag').textContent = emp.discord_tag||'Espace Employé'
  document.title = (emp.discord_tag||'Employé')+' — Espace'
  if (emp.first_login||!emp.password_hash) { el('step-pwd').style.display='none'; el('step-newpwd').style.display='flex' }
}
function showDead(msg) { document.body.innerHTML=`<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;color:#555;font-size:14px">${msg}</div>` }
async function doLogin() {
  const pwd=el('inp-pwd').value.trim(); if(!pwd) return showErr('Entrez votre mot de passe')
  const d=await post('/api/employe/login-slug',{slug:SLUG,password:pwd})
  if(d.error) return showErr(d.error); launchApp()
}
async function setPassword() {
  const pwd=el('inp-newpwd').value.trim(); if(pwd.length<8) return showErr('Minimum 8 caractères')
  const d=await post('/api/employe/set-password-slug',{slug:SLUG,password:pwd})
  if(d.error) return showErr(d.error); launchApp()
}
function showErr(msg){ const e=el('login-error'); if(e){e.textContent=msg;e.style.display=msg?'block':'none'} }
async function launchApp(){ el('login-screen').style.display='none'; el('app').style.display='flex'; await loadAll() }
async function logout(){ stopTimer(); await post('/api/auth/logout',{}); location.reload() }

// ── CHARGEMENT PRINCIPAL ───────────────────────────────────────
async function loadAll() {
  const d = await api('/api/employe/dashboard')
  if (d.error) { showDead(d.error); return }
  const { emp, grade, prod_mois, vente_mois, ca_mois, minutes_mois, paye_prev, session_active, historique, avertissements, absences, config } = d
  _empId   = emp.discord_id
  _couleur = config?.couleur || '#C9A84C'

  // Couleur CSS dynamique
  document.documentElement.style.setProperty('--acc', _couleur)
  document.documentElement.style.setProperty('--acc-d', _couleur+'22')
  document.documentElement.style.setProperty('--acc-b', _couleur+'55')

  // Nom entreprise
  const et = el('entreprise-titre'); if(et) et.textContent=(config?.emoji||'🍽️')+' '+(config?.nom||'Espace Employé')

  // ── Profil card ─────────────────────────────────────────────
  // Initiales en attendant
  const avEl = el('profil-avatar')
  if (avEl) {
    avEl.innerHTML = `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:var(--acc)">${emp.avatar_initiales||emp.discord_tag?.slice(0,2).toUpperCase()||'RP'}</div>`
  }
  const nameEl=el('profil-name'); if(nameEl) nameEl.textContent=emp.discord_tag||'Employé'
  const gradeEl=el('profil-grade')
  if (gradeEl) gradeEl.innerHTML=`<span style="background:${grade?.couleur||_couleur}22;border:0.5px solid ${grade?.couleur||_couleur}55;border-radius:99px;padding:3px 12px;font-size:12px;font-weight:600;color:${grade?.couleur||_couleur}">${grade?.emoji||'⭐'} ${emp.grade||'Employé'}</span>`
  const embaucheEl=el('profil-embauche'); if(embaucheEl) embaucheEl.textContent='Depuis '+fmtD(emp.date_embauche)

  // Charger vraie photo + vrais rôles Discord (async, sans bloquer)
  api(`/api/employe/discord-profile/${emp.discord_id}`).then(prof => {
    if (prof.avatar_url && avEl) {
      const img=document.createElement('img')
      img.style.cssText='width:100%;height:100%;object-fit:cover;border-radius:50%'
      img.onload = () => { avEl.innerHTML=''; avEl.appendChild(img) }
      img.onerror = () => {}
      img.src = prof.avatar_url
    }
    // Rôles Discord réels
    if (prof.roles?.length) {
      const rolesEl = el('profil-roles')
      if (rolesEl) {
        rolesEl.innerHTML = prof.roles.slice(0,6).map(r =>
          `<span style="background:${r.couleur}18;border:0.5px solid ${r.couleur}44;border-radius:99px;padding:2px 9px;font-size:11px;font-weight:500;color:${r.couleur}">${r.nom}</span>`
        ).join('')
      }
    }
  }).catch(()=>{})

  // ── Stats ────────────────────────────────────────────────────
  const setS = (id,v) => { const e=el(id); if(e) e.textContent=v }
  setS('stat-prod', prod_mois||0)
  setS('stat-ca', '$'+fmt(ca_mois))
  setS('stat-temps', fmtH(minutes_mois||0))
  setS('stat-paye', '~$'+fmt(Math.round(paye_prev||0)))

  // ── Service ──────────────────────────────────────────────────
  if (session_active?.debut) {
    _serviceDebut = new Date(session_active.debut)
    startTimer()
    const btn=el('btn-service')
    if(btn){btn.textContent='⏹ Fin de service';btn.style.background='rgba(239,68,68,.12)';btn.style.borderColor='rgba(239,68,68,.4)';btn.style.color='#ef4444'}
  }

  // ── Historique ───────────────────────────────────────────────
  const hist=el('historique-list')
  if (hist) {
    hist.innerHTML = historique.length ? historique.map(p=>`
      <div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:0.5px solid rgba(255,255,255,.06);font-size:12px">
        <span style="padding:2px 8px;border-radius:99px;font-size:10px;background:${p.type==='vente'?'rgba(34,197,94,.1)':'rgba(96,165,250,.1)'};color:${p.type==='vente'?'#22c55e':'#60a5fa'};border:0.5px solid ${p.type==='vente'?'rgba(34,197,94,.25)':'rgba(96,165,250,.25)'}">${p.type==='vente'?'Vente':'Prod'}</span>
        <span style="flex:1;color:#eceef3">${p.article}</span>
        <span style="color:var(--acc);font-weight:600">${p.prix?'$'+fmt(p.prix):p.quantite+'x'}</span>
        <span style="color:#3d4260">${fmtD(p.date)}</span>
      </div>`).join('') : '<div style="color:#3d4260;font-size:12px;padding:12px 0;text-align:center">Aucune déclaration ce mois</div>'
  }

  // ── Avertissements ───────────────────────────────────────────
  const avList=el('avert-list')
  if(avList) {
    avList.innerHTML = avertissements.length ? avertissements.map(a=>`
      <div style="padding:9px 12px;background:rgba(239,68,68,.06);border:.5px solid rgba(239,68,68,.2);border-radius:8px;font-size:12px;margin-bottom:6px">
        <div style="color:#ef4444;margin-bottom:2px">${a.message}</div>
        <div style="color:#3d4260;font-size:11px">${fmtD(a.date)}</div>
      </div>`).join('') : '<div style="color:#3d4260;font-size:12px">Aucun avertissement</div>'
  }

  // ── Absences ─────────────────────────────────────────────────
  renderAbsences(absences)

  // ── Articles select ──────────────────────────────────────────
  const articleSel=el('prod-article')
  if (articleSel) {
    const arts=await api('/api/employe/articles').catch(()=>([]))
    articleSel.innerHTML=arts.map(a=>`<option>${typeof a==='object'?a.nom:a}</option>`).join('')
  }
}

// ── ABSENCES ──────────────────────────────────────────────────
function renderAbsences(absences) {
  const list=el('absences-list'); if(!list) return
  const pills={ en_attente:'rgba(250,204,21,.12)|rgba(250,204,21,.3)|#facc15|En attente', accepte:'rgba(34,197,94,.1)|rgba(34,197,94,.3)|#22c55e|Acceptée', refuse:'rgba(239,68,68,.1)|rgba(239,68,68,.3)|#ef4444|Refusée' }
  list.innerHTML = absences.length ? absences.map(a => {
    const [bg,bd,col,lbl] = (pills[a.statut]||pills.en_attente).split('|')
    return `<div style="padding:10px 12px;background:rgba(255,255,255,.03);border:.5px solid rgba(255,255,255,.07);border-radius:10px;font-size:12px;margin-bottom:7px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-weight:500;color:#eceef3">${a.date_debut} → ${a.date_fin}</span>
        <span style="background:${bg};border:.5px solid ${bd};border-radius:99px;padding:1px 8px;font-size:10px;color:${col}">${lbl}</span>
      </div>
      <div style="color:#7a7f96">${a.raison||'Aucune raison précisée'}</div>
      ${a.note_patron?`<div style="color:#c9a84c;margin-top:3px;font-size:11px">Note patron : ${a.note_patron}</div>`:''}
    </div>`
  }).join('') : '<div style="color:#3d4260;font-size:12px;text-align:center;padding:12px 0">Aucune absence déclarée</div>'
}

async function declarerAbsence() {
  const debut=el('abs-debut')?.value, fin=el('abs-fin')?.value, raison=el('abs-raison')?.value
  if (!debut||!fin) return alert('Renseigne les dates')
  if (new Date(fin)<new Date(debut)) return alert('La date de fin doit être après le début')
  const d=await post('/api/employe/absences',{date_debut:debut,date_fin:fin,raison})
  if (d.ok) { alert('Absence déclarée — en attente de validation patron'); el('abs-debut').value=''; el('abs-fin').value=''; el('abs-raison').value=''; loadAll() }
  else alert(d.error||'Erreur')
}

// ── SERVICE ───────────────────────────────────────────────────
function startTimer() {
  if (_timer) clearInterval(_timer)
  _timer=setInterval(()=>{
    const el2=el('chrono'); if(!el2) return
    const diff=Math.floor((Date.now()-_serviceDebut)/1000)
    const h=Math.floor(diff/3600),m=Math.floor((diff%3600)/60),s=diff%60
    el2.textContent=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`
  },1000)
}
function stopTimer(){ if(_timer){clearInterval(_timer);_timer=null} }

async function toggleService() {
  const btn=el('btn-service')
  if (_serviceDebut) {
    const d=await post('/api/employe/service/fin',{})
    if(d.ok){ stopTimer(); _serviceDebut=null; el('chrono').textContent='00:00:00'; if(btn){btn.textContent='▶ Prendre le service';btn.style.background='rgba(34,197,94,.1)';btn.style.borderColor='rgba(34,197,94,.3)';btn.style.color='#22c55e'} loadAll() }
  } else {
    const d=await post('/api/employe/service/debut',{})
    if(d.ok){ _serviceDebut=new Date(); startTimer(); if(btn){btn.textContent='⏹ Fin de service';btn.style.background='rgba(239,68,68,.12)';btn.style.borderColor='rgba(239,68,68,.4)';btn.style.color='#ef4444'} }
  }
}

// ── DÉCLARATIONS ──────────────────────────────────────────────
async function declarer(type) {
  const article=el('prod-article')?.value, preuve=el('prod-preuve')?.files?.[0]
  const prix=el('prod-prix')?.value
  if (!article) return alert('Sélectionne un article')
  if (!preuve) return alert('Ajoute une preuve (photo obligatoire)')
  const fd=new FormData(); fd.append('type',type); fd.append('article',article); fd.append('quantite','1'); fd.append('prix',prix||'0'); fd.append('preuve',preuve)
  const r=await fetch('/api/employe/production',{method:'POST',body:fd,credentials:'same-origin'})
  const d=await r.json()
  if(d.ok){ alert('Déclaration enregistrée ✅'); el('prod-preuve').value=''; if(el('prod-prix')) el('prod-prix').value=''; loadAll() }
  else alert(d.error||'Erreur')
}

initPage()
