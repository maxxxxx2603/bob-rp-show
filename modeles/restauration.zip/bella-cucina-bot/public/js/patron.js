const api  = async (u,o={}) => (await fetch(u,{headers:{'Content-Type':'application/json'},credentials:'same-origin',...o})).json()
const post = (u,b) => api(u,{method:'POST',body:JSON.stringify(b)})
const put  = (u,b) => api(u,{method:'PUT', body:JSON.stringify(b)})
const el   = id => document.getElementById(id)
const fmtD = s  => s ? new Date(s).toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'2-digit'}) : '—'
const fmt  = n  => Number(n||0).toLocaleString('fr-FR')

let _couleur = '#C9A84C'

// ── LOGIN ──────────────────────────────────────────────────────
async function initPatron() {
  const me = await api('/api/auth/me').catch(()=>({}))
  if (me.role==='patron') { launchPatron(); return }
  const t = await post('/api/patron/login',{password:'__probe__'})
  if (t.setup) el('p-setup').style.display='block'
}

async function loginPatron() {
  const d = await post('/api/patron/login',{password:el('p-pwd').value})
  if(d.error) { el('p-err').textContent=d.error; el('p-err').style.display='block'; return }
  launchPatron()
}

async function launchPatron() {
  el('login-patron').style.display='none'; el('app-patron').style.display='block'
  await loadDashboard()
}

async function logoutPatron() { await post('/api/patron/logout',{}); location.reload() }

// ── DASHBOARD ─────────────────────────────────────────────────
let _data = null
async function loadDashboard() {
  _data = await api('/api/patron/dashboard')
  _couleur = _data.config?.couleur || '#C9A84C'
  document.documentElement.style.setProperty('--acc', _couleur)
  document.documentElement.style.setProperty('--acc-b', _couleur+'55')

  const et=el('p-ent-titre'); if(et) et.textContent=(_data.config?.emoji||'🍽️')+' '+(_data.config?.nom||'')

  // Stats
  const ss=(id,v)=>{ const e=el(id); if(e) e.textContent=v }
  ss('ps-emp', _data.stats.employes)
  ss('ps-ca',  '$'+fmt(_data.stats.ca_mois))
  ss('ps-cv',  _data.stats.cv_att)
  ss('ps-abs', _data.stats.abs_att)

  renderEquipe(_data.equipe)
  renderCV(_data.cv_att)
  renderAbsencesPatron(_data.absences)
  renderProductions(_data.prods_rec)
}

// ── ÉQUIPE ────────────────────────────────────────────────────
function renderEquipe(equipe) {
  const list=el('equipe-list'); if(!list) return
  list.innerHTML = equipe.map(emp => `
    <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:.5px solid rgba(255,255,255,.06)">
      <div style="width:36px;height:36px;border-radius:50%;overflow:hidden;background:${emp.grade_couleur||_couleur}22;border:.5px solid ${emp.grade_couleur||_couleur}44;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:13px;font-weight:700;color:${emp.grade_couleur||_couleur}">
        ${emp.discord_avatar?`<img src="${emp.discord_avatar}" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.textContent='${(emp.discord_tag||'?').slice(0,2).toUpperCase()}'">`:((emp.discord_tag||'??').slice(0,2).toUpperCase())}
      </div>
      <div style="flex:1">
        <div style="font-size:13px;font-weight:500">${emp.discord_tag}</div>
        <div style="font-size:11px;color:${emp.grade_couleur||_couleur}">${emp.grade}</div>
      </div>
      <div style="display:flex;gap:6px">
        <select onchange="changerGrade('${emp.discord_id}',this)" style="font-size:11px;padding:4px 6px;width:110px">
          <option value="">Changer grade…</option>
          ${(_data.equipe.map(()=>'')||[]).join('')}
        </select>
        <button onclick="avertir('${emp.discord_id}','${emp.discord_tag}')" style="background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#ef4444;border-radius:6px;padding:4px 8px;cursor:pointer;font-size:11px"><i class="ti ti-alert-triangle"></i></button>
      </div>
    </div>`).join('')

  // Charger les grades pour les selects
  api('/api/patron/grades').then(grades => {
    list.querySelectorAll('select').forEach(sel => {
      const current = sel.closest('[style]')?.querySelector('[style*="font-size:11px"]')?.textContent?.trim()
      sel.innerHTML = `<option value="">Changer grade…</option>` + grades.map(g=>`<option value="${g.nom}" ${g.nom===current?'selected':''}>${g.emoji||''} ${g.nom}</option>`).join('')
    })
  })
}

async function changerGrade(discordId, sel) {
  if (!sel.value) return
  const d = await put(`/api/patron/employes/${discordId}`,{grade:sel.value})
  d.ok ? (toast('Grade mis à jour','success'), loadDashboard()) : toast(d.error,'error')
}

async function avertir(discordId, tag) {
  const msg = prompt(`Avertissement pour ${tag} :`)
  if (!msg) return
  const d = await put(`/api/patron/employes/${discordId}`,{avertissement:msg})
  d.ok ? toast('Avertissement envoyé','success') : toast(d.error,'error')
}

// ── CV ────────────────────────────────────────────────────────
function renderCV(cvs) {
  const list=el('cv-list'); if(!list) return
  list.innerHTML = cvs.length ? cvs.map(cv => {
    const reps = JSON.parse(cv.reponses||'{}')
    return `<div style="background:rgba(255,255,255,.03);border:.5px solid rgba(255,255,255,.07);border-radius:12px;padding:14px;margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <div style="font-weight:600">${cv.discord_tag}</div>
        <div style="font-size:11px;color:#7a7f96">${fmtD(cv.date_soumission)}</div>
      </div>
      ${Object.entries(reps).map(([q,r])=>`<div style="font-size:12px;margin-bottom:6px"><span style="color:#7a7f96">${q}</span><br><span style="color:#eceef3">${r}</span></div>`).join('')}
      <textarea id="note-cv-${cv.id}" placeholder="Note (optionnel)…" rows="2" style="margin-top:8px;font-size:12px"></textarea>
      <div style="display:flex;gap:8px;margin-top:8px">
        <button onclick="traiterCV(${cv.id},'accepte')" style="flex:1;padding:8px;border-radius:7px;background:rgba(34,197,94,.1);border:.5px solid rgba(34,197,94,.3);color:#22c55e;cursor:pointer;font-size:12px;font-weight:600"><i class="ti ti-check"></i> Accepter</button>
        <button onclick="traiterCV(${cv.id},'refuse')" style="flex:1;padding:8px;border-radius:7px;background:rgba(239,68,68,.08);border:.5px solid rgba(239,68,68,.25);color:#ef4444;cursor:pointer;font-size:12px;font-weight:600"><i class="ti ti-x"></i> Refuser</button>
      </div>
    </div>`
  }).join('') : '<div style="color:#3d4260;font-size:12px;text-align:center;padding:16px">Aucun CV en attente</div>'
}

async function traiterCV(id, statut) {
  const note = el(`note-cv-${id}`)?.value||''
  const d = await put(`/api/patron/cv/${id}`,{statut,note})
  d.ok ? (toast(statut==='accepte'?'CV accepté ✅':'CV refusé','success'), loadDashboard()) : toast(d.error,'error')
}

// ── ABSENCES PATRON ───────────────────────────────────────────
function renderAbsencesPatron(absences) {
  const list=el('absences-patron-list'); if(!list) return
  const pills={ en_attente:'rgba(250,204,21,.12)|rgba(250,204,21,.3)|#facc15|En attente', accepte:'rgba(34,197,94,.1)|rgba(34,197,94,.3)|#22c55e|Acceptée', refuse:'rgba(239,68,68,.1)|rgba(239,68,68,.3)|#ef4444|Refusée' }
  list.innerHTML = absences.length ? absences.map(a => {
    const [bg,bd,col,lbl] = (pills[a.statut]||pills.en_attente).split('|')
    const isPending = a.statut==='en_attente'
    return `<div style="background:rgba(255,255,255,.03);border:.5px solid rgba(255,255,255,.07);border-radius:10px;padding:12px;margin-bottom:7px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">
        <div>
          <div style="font-size:13px;font-weight:500">${a.discord_tag} <span style="font-size:11px;color:${_couleur}">${a.grade}</span></div>
          <div style="font-size:12px;color:#7a7f96;margin-top:2px">${a.date_debut} → ${a.date_fin}</div>
          <div style="font-size:11px;color:#3d4260;margin-top:2px">${a.raison||'Aucune raison'}</div>
        </div>
        <span style="background:${bg};border:.5px solid ${bd};border-radius:99px;padding:2px 9px;font-size:10px;color:${col};white-space:nowrap">${lbl}</span>
      </div>
      ${isPending ? `
        <textarea id="note-abs-${a.id}" placeholder="Note (optionnel)…" rows="1" style="font-size:12px;margin-bottom:6px"></textarea>
        <div style="display:flex;gap:6px">
          <button onclick="traiterAbsence(${a.id},'accepte')" style="flex:1;padding:7px;border-radius:7px;background:rgba(34,197,94,.1);border:.5px solid rgba(34,197,94,.3);color:#22c55e;cursor:pointer;font-size:12px;font-weight:600"><i class="ti ti-check"></i> Accepter</button>
          <button onclick="traiterAbsence(${a.id},'refuse')" style="flex:1;padding:7px;border-radius:7px;background:rgba(239,68,68,.08);border:.5px solid rgba(239,68,68,.25);color:#ef4444;cursor:pointer;font-size:12px;font-weight:600"><i class="ti ti-x"></i> Refuser</button>
        </div>` : a.note_patron ? `<div style="font-size:11px;color:${_couleur}">Note : ${a.note_patron}</div>` : ''}
    </div>`
  }).join('') : '<div style="color:#3d4260;font-size:12px;text-align:center;padding:12px">Aucune absence</div>'
}

async function traiterAbsence(id, statut) {
  const note = el(`note-abs-${id}`)?.value||''
  const d = await put(`/api/patron/absences/${id}`,{statut,note})
  d.ok ? (toast(statut==='accepte'?'Absence acceptée ✅':'Absence refusée','success'), loadDashboard()) : toast(d.error,'error')
}

// ── PRODUCTIONS ───────────────────────────────────────────────
function renderProductions(prods) {
  const list=el('prods-list'); if(!list) return
  list.innerHTML = prods.length ? prods.map(p=>`
    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:.5px solid rgba(255,255,255,.06);font-size:12px">
      <span style="padding:2px 8px;border-radius:99px;font-size:10px;background:${p.type==='vente'?'rgba(34,197,94,.1)':'rgba(96,165,250,.1)'};color:${p.type==='vente'?'#22c55e':'#60a5fa'};border:.5px solid ${p.type==='vente'?'rgba(34,197,94,.25)':'rgba(96,165,250,.25)'}">${p.type==='vente'?'Vente':'Prod'}</span>
      <span style="flex:1;color:#eceef3">${p.article}</span>
      <span style="color:#7a7f96">${p.discord_tag}</span>
      ${p.prix?`<span style="color:${_couleur};font-weight:600">$${fmt(p.prix)}</span>`:''}
      ${p.preuve_filename?`<a href="/api/patron/uploads/${p.preuve_filename}" target="_blank" style="color:#60a5fa;font-size:11px"><i class="ti ti-photo"></i></a>`:''}
    </div>`).join('') : '<div style="color:#3d4260;font-size:12px;text-align:center;padding:12px">Aucune déclaration</div>'
}

// ── TOAST ──────────────────────────────────────────────────────
function toast(msg, type='success') {
  const cols={success:'#22c55e',error:'#ef4444',warn:'#facc15',info:_couleur}
  const t=document.createElement('div')
  t.style.cssText=`position:fixed;bottom:20px;right:20px;background:#0f1013;border:.5px solid rgba(255,255,255,.15);border-radius:10px;padding:10px 16px;font-size:13px;color:${cols[type]||cols.info};z-index:999;animation:slideIn .3s ease`
  t.textContent=msg; document.body.appendChild(t); setTimeout(()=>t.remove(),3000)
}

initPatron()
