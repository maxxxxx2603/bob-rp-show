const { EmbedBuilder } = require('discord.js')
const bcrypt = require('bcryptjs')

module.exports = async function buttonHandler(interaction, action, args, client, db) {
  const config = Object.fromEntries(db.prepare('SELECT key, value FROM config').all().map(r => [r.key, r.value]))

  // ── Accepter CV ─────────────────────────────────────────────
  if (action === 'cv_accept') {
    const targetId = args[0]

    // Vérif patron
    const patronRole = interaction.guild.roles.cache.get(config.role_patron)
    if (patronRole && !interaction.member.roles.cache.has(config.role_patron)) {
      return interaction.reply({ content: '❌ Réservé au patron.', ephemeral: true })
    }

    // Mise à jour CV
    db.prepare("UPDATE cv SET statut = 'accepte' WHERE discord_id = ? AND statut = 'en_attente'").run(targetId)

    // Créer compte employé si inexistant
    const existingEmp = db.prepare('SELECT id FROM employes WHERE discord_id = ?').get(targetId)
    if (!existingEmp) {
      const member = interaction.guild.members.cache.get(targetId)
      db.prepare('INSERT OR IGNORE INTO employes (discord_id, discord_tag) VALUES (?, ?)').run(
        targetId, member?.user.tag || targetId
      )
    }

    // Rôle attente entretien
    if (config.role_attente_entretien) {
      const member = await interaction.guild.members.fetch(targetId).catch(() => null)
      if (member) {
        await member.roles.add(config.role_attente_entretien).catch(() => {})
        // Envoyer DM
        member.send(`✅ **Ta candidature chez ${config.entreprise_nom} a été acceptée !**\nTu es maintenant en attente d'entretien.\n\nConnecte-toi sur : ${process.env.WEB_URL || 'http://localhost:3000'}\nUtilise ton ID Discord : \`${targetId}\` pour créer ton compte.`).catch(() => {})
      }
    }

    // Désactiver les boutons du message
    await interaction.update({
      components: [],
      embeds: [interaction.message.embeds[0], new EmbedBuilder()
        .setColor(0x4ade80)
        .setDescription(`✅ Accepté par <@${interaction.user.id}> — Rôle attente entretien attribué`)
      ]
    })
  }

  // ── Refuser CV ──────────────────────────────────────────────
  if (action === 'cv_refuse') {
    const targetId = args[0]
    db.prepare("UPDATE cv SET statut = 'refuse' WHERE discord_id = ? AND statut = 'en_attente'").run(targetId)

    const member = await interaction.guild.members.fetch(targetId).catch(() => null)
    if (member) {
      member.send(`❌ **Ta candidature chez ${config.entreprise_nom} n'a pas été retenue.**\nN'hésite pas à repostuler plus tard.`).catch(() => {})
    }

    await interaction.update({
      components: [],
      embeds: [interaction.message.embeds[0], new EmbedBuilder()
        .setColor(0xef4444)
        .setDescription(`❌ Refusé par <@${interaction.user.id}>`)
      ]
    })
  }
}
