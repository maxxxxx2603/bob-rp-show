const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js')

module.exports = async function modalHandler(interaction, client, db) {
  if (interaction.customId === 'cv_modal') {
    const config = Object.fromEntries(db.prepare('SELECT key, value FROM config').all().map(r => [r.key, r.value]))
    const questions = db.prepare('SELECT * FROM questions_cv WHERE actif = 1 ORDER BY ordre').all()

    const reponses = {}
    questions.slice(0, 5).forEach(q => {
      const val = interaction.fields.getTextInputValue(`q_${q.id}`)
      if (val) reponses[q.question] = val
    })

    // Enregistrement DB
    const existing = db.prepare('SELECT id FROM cv WHERE discord_id = ? AND statut = ?').get(interaction.user.id, 'en_attente')
    if (existing) {
      return interaction.reply({ content: '❌ Tu as déjà une candidature en attente !', ephemeral: true })
    }

    db.prepare('INSERT INTO cv (discord_id, discord_tag, reponses) VALUES (?, ?, ?)').run(
      interaction.user.id,
      interaction.user.tag,
      JSON.stringify(reponses)
    )

    // Embed dans channel CV
    const channelId = config.channel_cv
    const cvChannel = channelId ? interaction.guild.channels.cache.get(channelId) : null

    const embed = new EmbedBuilder()
      .setColor(parseInt(config.entreprise_couleur?.replace('#', '') || 'C9A84C', 16))
      .setTitle(`${config.entreprise_emoji || '🍽️'} Nouvelle candidature`)
      .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
      .addFields(
        ...Object.entries(reponses).map(([q, r]) => ({ name: q, value: r.substring(0, 1024), inline: false }))
      )
      .setTimestamp()

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`cv_accept:${interaction.user.id}`).setLabel('✅ Accepter').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`cv_refuse:${interaction.user.id}`).setLabel('❌ Refuser').setStyle(ButtonStyle.Danger),
    )

    if (cvChannel) cvChannel.send({ embeds: [embed], components: [buttons] })

    await interaction.reply({
      content: `✅ Ta candidature a bien été envoyée ! Tu seras contacté(e) sur Discord.\n\n💡 Connecte-toi sur le site : **${config.web_url || process.env.WEB_URL || 'http://localhost:3000'}** avec ton ID Discord pour accéder à ton espace employé si tu es accepté(e).`,
      ephemeral: true
    })
  }
}
