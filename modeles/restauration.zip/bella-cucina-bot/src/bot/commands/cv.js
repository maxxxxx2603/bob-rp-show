const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js')

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cv')
    .setDescription('Postuler dans l\'entreprise'),

  async execute(interaction, client, db) {
    const questions = db.prepare('SELECT * FROM questions_cv WHERE actif = 1 ORDER BY ordre').all()
    if (questions.length === 0) {
      return interaction.reply({ content: '❌ Aucune question CV configurée.', ephemeral: true })
    }

    // Modal Discord (max 5 champs)
    const modal = new ModalBuilder()
      .setCustomId('cv_modal')
      .setTitle('📄 Candidature — ' + (db.prepare("SELECT value FROM config WHERE key='entreprise_nom'").get()?.value || 'Entreprise RP'))

    const rows = questions.slice(0, 5).map(q => {
      const input = new TextInputBuilder()
        .setCustomId(`q_${q.id}`)
        .setLabel(q.question.substring(0, 45))
        .setStyle(q.question.length > 60 ? TextInputStyle.Paragraph : TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(500)
      return new ActionRowBuilder().addComponents(input)
    })

    modal.addComponents(...rows)
    await interaction.showModal(modal)
  }
}
