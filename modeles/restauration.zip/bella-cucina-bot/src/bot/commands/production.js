const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js')

module.exports = {
  data: new SlashCommandBuilder()
    .setName('production')
    .setDescription('Déclarer une production ou une vente')
    .addSubcommand(sub =>
      sub.setName('produire')
        .setDescription('Déclarer une production')
        .addStringOption(opt => opt.setName('article').setDescription('Article produit').setRequired(true).setAutocomplete(true))
        .addIntegerOption(opt => opt.setName('quantite').setDescription('Quantité').setRequired(true).setMinValue(1))
        .addAttachmentOption(opt => opt.setName('preuve').setDescription('Capture d\'écran obligatoire').setRequired(true))
    )
    .addSubcommand(sub =>
      sub.setName('vendre')
        .setDescription('Déclarer une vente')
        .addStringOption(opt => opt.setName('article').setDescription('Article vendu').setRequired(true).setAutocomplete(true))
        .addIntegerOption(opt => opt.setName('quantite').setDescription('Quantité').setRequired(true).setMinValue(1))
        .addIntegerOption(opt => opt.setName('prix').setDescription('Prix de vente total ($)').setRequired(true))
        .addAttachmentOption(opt => opt.setName('preuve').setDescription('Capture d\'écran obligatoire').setRequired(true))
    ),

  async autocomplete(interaction, db) {
    const articles = db.prepare('SELECT nom FROM articles WHERE actif = 1').all()
    await interaction.respond(articles.map(a => ({ name: a.nom, value: a.nom })))
  },

  async execute(interaction, client, db) {
    const sub = interaction.options.getSubcommand()
    const article = interaction.options.getString('article')
    const quantite = interaction.options.getInteger('quantite')
    const preuve = interaction.options.getAttachment('preuve')
    const config = Object.fromEntries(db.prepare('SELECT key, value FROM config').all().map(r => [r.key, r.value]))

    if (!preuve.contentType?.startsWith('image/')) {
      return interaction.reply({ content: '❌ La preuve doit être une image (PNG, JPG).', ephemeral: true })
    }

    let prix = 0
    let type = 'production'

    if (sub === 'vendre') {
      prix = interaction.options.getInteger('prix')
      type = 'vente'
      // Mise à jour inventaire
      db.prepare('UPDATE inventaire SET quantite = MAX(0, quantite - ?) WHERE article = ?').run(quantite, article)
    } else {
      // Mise à jour inventaire
      db.prepare('UPDATE inventaire SET quantite = MIN(quantite + ?, quantite_max) WHERE article = ?').run(quantite, article)
    }

    // Enregistrement DB
    const result = db.prepare(
      'INSERT INTO productions (employe_discord_id, type, article, quantite, prix, preuve_filename) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(interaction.user.id, type, article, quantite, prix, preuve.url)

    // Vérification stock bas
    const stock = db.prepare('SELECT * FROM inventaire WHERE article = ?').get(article)
    if (stock && stock.quantite <= stock.seuil_alerte) {
      const alertChannel = interaction.guild.channels.cache.get(config.channel_alertes)
      if (alertChannel) {
        alertChannel.send({
          embeds: [new EmbedBuilder()
            .setColor(0xfacc15)
            .setTitle('⚠️ Stock bas')
            .setDescription(`**${article}** : ${stock.quantite} restants (seuil : ${stock.seuil_alerte})`)
          ]
        })
      }
    }

    const embed = new EmbedBuilder()
      .setColor(type === 'vente' ? 0x4ade80 : 0x3b82f6)
      .setTitle(type === 'vente' ? '💰 Vente déclarée' : '🔧 Production déclarée')
      .addFields(
        { name: 'Employé', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'Article', value: article, inline: true },
        { name: 'Quantité', value: `${quantite}`, inline: true },
        ...(type === 'vente' ? [{ name: 'Prix', value: `$${prix.toLocaleString()}`, inline: true }] : []),
        { name: 'Preuve', value: `[Voir la capture](${preuve.url})`, inline: true },
        { name: 'ID entrée', value: `#${result.lastInsertRowid}`, inline: true }
      )
      .setImage(preuve.url)
      .setTimestamp()

    // Log dans channel prod/ventes
    const channelId = type === 'vente' ? config.channel_ventes : config.channel_productions
    const logChannel = channelId ? interaction.guild.channels.cache.get(channelId) : null
    if (logChannel) logChannel.send({ embeds: [embed] })

    await interaction.reply({ embeds: [embed], ephemeral: true })
  }
}
