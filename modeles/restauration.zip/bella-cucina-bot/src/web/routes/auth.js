const router = require('express').Router()
const bcrypt = require('bcryptjs')
const db = require('../../db/database')

// POST /api/auth/patron — login patron (mdp unique)
router.post('/patron', async (req, res) => {
  const { password } = req.body
  const patronPwd = db.prepare("SELECT value FROM config WHERE key='patron_password'").get()

  if (!patronPwd) {
    if (!password || password.length < 8) return res.status(400).json({ error: 'Définissez un mot de passe patron (min 8 car.)', setup: true })
    const hash = await bcrypt.hash(password, 12)
    db.prepare("INSERT OR REPLACE INTO config (key,value) VALUES ('patron_password',?)").run(hash)
    req.session.userId = 'patron'
    req.session.role = 'patron'
    return res.json({ ok: true, role: 'patron', first: true })
  }

  const valid = await bcrypt.compare(password, patronPwd.value)
  if (!valid) return res.status(401).json({ error: 'Mot de passe incorrect' })
  req.session.userId = 'patron'
  req.session.role = 'patron'
  res.json({ ok: true, role: 'patron' })
})

// POST /api/auth/logout
router.post('/logout', (req, res) => { req.session.destroy(); res.json({ ok: true }) })

// GET /api/auth/me
router.get('/me', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Non connecté' })
  if (req.session.role === 'patron') return res.json({ role: 'patron' })
  const emp = db.prepare('SELECT discord_id,discord_tag,poste,slug FROM employes WHERE discord_id=?').get(req.session.empDiscordId)
  res.json({ role: 'employe', ...emp })
})

module.exports = router
