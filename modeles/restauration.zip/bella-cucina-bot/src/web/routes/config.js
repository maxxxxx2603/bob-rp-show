const router = require('express').Router()
const db = require('../../db/database')

function requirePatron(req, res, next) {
  if (req.session.role !== 'patron') return res.status(403).json({ error: 'Patron requis' })
  next()
}
router.use(requirePatron)

// GET /api/config — toute la config
router.get('/', (req, res) => {
  const cfg = Object.fromEntries(db.prepare('SELECT key, value FROM config').all().map(r => [r.key, r.value]))
  const questions = db.prepare('SELECT * FROM questions_cv WHERE actif = 1 ORDER BY ordre').all()
  const articles = db.prepare('SELECT * FROM articles WHERE actif = 1').all()
  res.json({ config: cfg, questions, articles })
})

// POST /api/config — sauvegarder
router.post('/', (req, res) => {
  const { config } = req.body
  const insert = db.prepare('INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)')
  const insertMany = db.transaction(entries => {
    for (const [k, v] of entries) insert.run(k, String(v))
  })
  insertMany(Object.entries(config || {}))
  res.json({ ok: true })
})

// POST /api/config/questions/add
router.post('/questions/add', (req, res) => {
  const { question } = req.body
  const max = db.prepare('SELECT MAX(ordre) as m FROM questions_cv').get().m || 0
  db.prepare('INSERT INTO questions_cv (ordre, question) VALUES (?, ?)').run(max + 1, question)
  res.json({ ok: true })
})

// DELETE /api/config/questions/:id
router.delete('/questions/:id', (req, res) => {
  db.prepare('UPDATE questions_cv SET actif = 0 WHERE id = ?').run(req.params.id)
  res.json({ ok: true })
})

// POST /api/config/articles/add
router.post('/articles/add', (req, res) => {
  const { nom } = req.body
  db.prepare('INSERT OR IGNORE INTO articles (nom) VALUES (?)').run(nom)
  db.prepare('INSERT OR IGNORE INTO inventaire (article) VALUES (?)').run(nom)
  res.json({ ok: true })
})

// DELETE /api/config/articles/:nom
router.delete('/articles/:nom', (req, res) => {
  db.prepare('UPDATE articles SET actif = 0 WHERE nom = ?').run(req.params.nom)
  res.json({ ok: true })
})

module.exports = router
