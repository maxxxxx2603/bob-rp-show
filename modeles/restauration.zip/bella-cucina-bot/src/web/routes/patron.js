const router  = require('express').Router()
const express = require('express')
const { db, uploadsDir, cfg, setCfg } = require('../../db/database')

function requirePatron(req,res,next) { if(!req.session.patron) return res.status(403).json({error:'Non authentifié'}); next() }

// ── AUTH ──────────────────────────────────────────────────────
router.post('/login', async (req,res) => {
  const { password } = req.body
  const stored = cfg('patron_password')
  if (!stored) {
    if (!password || password.length < 8) return res.status(400).json({ error:'Min 8 caractères', setup:true })
    const bcrypt = require('bcryptjs')
    setCfg('patron_password', await bcrypt.hash(password, 12))
    req.session.patron = true; return res.json({ ok:true, first:true })
  }
  const bcrypt = require('bcryptjs')
  if (!await bcrypt.compare(password, stored)) return res.status(401).json({ error:'Mot de passe incorrect' })
  req.session.patron = true; res.json({ ok:true })
})
router.post('/logout', (req,res) => { req.session.destroy(); res.json({ok:true}) })

// ── DASHBOARD ─────────────────────────────────────────────────
router.get('/dashboard', requirePatron, (req,res) => {
  const now = new Date().toISOString().slice(0,7)
  const equipe     = db.prepare("SELECT * FROM employes WHERE actif=1 ORDER BY grade,discord_tag").all()
  const cv_att     = db.prepare("SELECT * FROM cv WHERE statut='en_attente' ORDER BY date_soumission DESC").all()
  const prods_rec  = db.prepare("SELECT p.*,e.discord_tag,e.grade FROM productions p JOIN employes e ON p.employe_discord_id=e.discord_id ORDER BY p.id DESC LIMIT 30").all()
  const absences   = db.prepare("SELECT a.*,e.discord_tag,e.grade,e.discord_avatar FROM absences a JOIN employes e ON a.employe_discord_id=e.discord_id ORDER BY a.id DESC LIMIT 30").all()
  const stats = {
    employes: equipe.length,
    ca_mois:  db.prepare("SELECT COALESCE(SUM(prix),0) as s FROM productions WHERE type='vente' AND date LIKE ?").get(`${now}%`).s,
    cv_att:   cv_att.length,
    abs_att:  db.prepare("SELECT COUNT(*) as c FROM absences WHERE statut='en_attente'").get().c,
  }
  const config = { couleur:cfg('entreprise_couleur'), nom:cfg('entreprise_nom'), emoji:cfg('entreprise_emoji') }
  const bot_ok = cfg('bot_actif')==='1'
  res.json({ equipe, cv_att, prods_rec, absences, stats, config, bot_ok })
})

// ── PARAMÈTRES (tout configurable depuis le site) ─────────────
router.get('/parametres', requirePatron, (req,res) => {
  // Retourner toute la config SAUF le mot de passe patron et le token (masqué)
  const rows = db.prepare('SELECT key,value FROM config').all()
  const result = {}
  for (const {key,value} of rows) {
    if (key === 'patron_password') continue
    if (key === 'discord_token') result[key] = value ? '••••'+value.slice(-6) : ''
    else result[key] = value
  }
  res.json(result)
})

router.post('/parametres', requirePatron, async (req,res) => {
  const { discord_token, ...rest } = req.body
  // Sauvegarder tous les champs sauf le token masqué
  for (const [k,v] of Object.entries(rest)) {
    if (k !== 'patron_password' && k !== 'bot_actif' && k !== 'bot_tag') setCfg(k, v)
  }
  // Token : sauvegarder seulement si c'est un vrai token (pas des ••••)
  if (discord_token && !discord_token.includes('••')) {
    setCfg('discord_token', discord_token)
    // Redémarrer le bot avec le nouveau token
    const { startBot } = require('../../bot/client')
    const r = await startBot()
    if (!r.ok) return res.json({ ok:true, bot_warn: r.error })
  }
  res.json({ ok:true })
})

// ── CONTRÔLE BOT ──────────────────────────────────────────────
router.post('/bot/start', requirePatron, async (req,res) => {
  const { startBot } = require('../../bot/client')
  const r = await startBot()
  res.json(r)
})
router.post('/bot/stop', requirePatron, async (req,res) => {
  const { stopBot } = require('../../bot/client')
  const r = await stopBot()
  res.json(r)
})
router.get('/bot/status', requirePatron, (req,res) => {
  const { getClient } = require('../../bot/client')
  const client = getClient()
  res.json({
    online: client?.isReady() || false,
    tag:    client?.user?.tag || cfg('bot_tag') || '',
    ping:   client?.ws?.ping || 0,
  })
})

// ── ÉQUIPE ────────────────────────────────────────────────────
router.get('/employes', requirePatron, (req,res) => {
  res.json(db.prepare("SELECT * FROM employes ORDER BY actif DESC,grade,discord_tag").all())
})
router.post('/employes', requirePatron, (req,res) => {
  const { discord_id, discord_tag, grade, slug } = req.body
  if (!discord_id||!discord_tag||!slug) return res.status(400).json({error:'Champs requis'})
  const gradeInfo = db.prepare('SELECT couleur,role_discord FROM grades WHERE nom=?').get(grade||'Employé')
  try {
    db.prepare('INSERT INTO employes (discord_id,discord_tag,grade,grade_couleur,slug,avatar_initiales) VALUES (?,?,?,?,?,?)')
      .run(discord_id, discord_tag, grade||'Employé', gradeInfo?.couleur||'#c9a84c', slug, discord_tag.slice(0,2).toUpperCase())
    // Rôle Discord
    const { getClient } = require('../../bot/client')
    const client = getClient()
    const rId = cfg('role_employe')
    if (client?.isReady() && rId) {
      client.guilds.cache.get(cfg('guild_id'))?.members.fetch(discord_id).then(m=>m.roles.add(rId)).catch(()=>{})
    }
    res.json({ ok:true })
  } catch { res.status(400).json({error:'Discord ID ou slug déjà utilisé'}) }
})
router.put('/employes/:id', requirePatron, (req,res) => {
  const { grade, actif, avertissement } = req.body
  const emp = db.prepare('SELECT * FROM employes WHERE discord_id=?').get(req.params.id)
  if (!emp) return res.status(404).json({error:'Introuvable'})
  if (avertissement !== undefined) {
    db.prepare('INSERT INTO avertissements (employe_discord_id,message) VALUES (?,?)').run(req.params.id, avertissement)
    return res.json({ok:true})
  }
  const gradeInfo = grade ? db.prepare('SELECT couleur,role_discord FROM grades WHERE nom=?').get(grade) : null
  db.prepare('UPDATE employes SET grade=?,grade_couleur=?,actif=? WHERE discord_id=?')
    .run(grade||emp.grade, gradeInfo?.couleur||emp.grade_couleur, actif===undefined?emp.actif:actif?1:0, req.params.id)
  if (gradeInfo?.role_discord) {
    const { getClient } = require('../../bot/client')
    const client = getClient()
    if (client?.isReady()) client.guilds.cache.get(cfg('guild_id'))?.members.fetch(req.params.id).then(m=>m.roles.add(gradeInfo.role_discord)).catch(()=>{})
  }
  res.json({ok:true})
})

// ── GRADES ────────────────────────────────────────────────────
router.get('/grades', requirePatron, (req,res) => res.json(db.prepare('SELECT * FROM grades ORDER BY ordre').all()))
router.post('/grades', requirePatron, (req,res) => {
  const { nom, couleur, emoji, ordre, mode_paye, taux_base, bonus_prod, bonus_vente, bonus_heure, prix_piece, role_discord } = req.body
  db.prepare('INSERT INTO grades (nom,couleur,emoji,ordre,mode_paye,taux_base,bonus_prod,bonus_vente,bonus_heure,prix_piece,role_discord) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
    .run(nom,couleur||'#c9a84c',emoji||'⭐',+ordre||0,mode_paye||'pourcentage',+taux_base||5,+bonus_prod||1,+bonus_vente||2,+bonus_heure||0.5,+prix_piece||150,role_discord||'')
  res.json({ok:true})
})
router.put('/grades/:id', requirePatron, (req,res) => {
  const { nom, couleur, emoji, mode_paye, taux_base, bonus_prod, bonus_vente, bonus_heure, prix_piece, role_discord } = req.body
  db.prepare('UPDATE grades SET nom=?,couleur=?,emoji=?,mode_paye=?,taux_base=?,bonus_prod=?,bonus_vente=?,bonus_heure=?,prix_piece=?,role_discord=? WHERE id=?')
    .run(nom,couleur,emoji||'⭐',mode_paye||'pourcentage',+taux_base,+bonus_prod,+bonus_vente,+bonus_heure,+prix_piece,role_discord||'',req.params.id)
  res.json({ok:true})
})
router.delete('/grades/:id', requirePatron, (req,res) => { db.prepare('DELETE FROM grades WHERE id=?').run(req.params.id); res.json({ok:true}) })

// ── ARTICLES ──────────────────────────────────────────────────
router.get('/articles', requirePatron, (req,res) => res.json(db.prepare('SELECT * FROM articles ORDER BY nom').all()))
router.post('/articles', requirePatron, (req,res) => {
  try { db.prepare('INSERT INTO articles (nom) VALUES (?)').run(req.body.nom); res.json({ok:true}) }
  catch { res.status(400).json({error:'Article déjà existant'}) }
})
router.delete('/articles/:id', requirePatron, (req,res) => { db.prepare('DELETE FROM articles WHERE id=?').run(req.params.id); res.json({ok:true}) })

// ── QUESTIONS CV ──────────────────────────────────────────────
router.get('/questions-cv', requirePatron, (req,res) => res.json(db.prepare('SELECT * FROM questions_cv ORDER BY ordre').all()))
router.post('/questions-cv', requirePatron, (req,res) => {
  const { question, ordre } = req.body
  db.prepare('INSERT INTO questions_cv (ordre,question) VALUES (?,?)').run(+ordre||0, question)
  res.json({ok:true})
})
router.put('/questions-cv/:id', requirePatron, (req,res) => {
  db.prepare('UPDATE questions_cv SET question=?,ordre=? WHERE id=?').run(req.body.question, +req.body.ordre||0, req.params.id)
  res.json({ok:true})
})
router.delete('/questions-cv/:id', requirePatron, (req,res) => { db.prepare('DELETE FROM questions_cv WHERE id=?').run(req.params.id); res.json({ok:true}) })

// ── CV ────────────────────────────────────────────────────────
router.put('/cv/:id', requirePatron, async (req,res) => {
  const { statut, note } = req.body
  const cv = db.prepare('SELECT * FROM cv WHERE id=?').get(req.params.id)
  if (!cv) return res.status(404).json({error:'Introuvable'})
  db.prepare('UPDATE cv SET statut=?,note_patron=? WHERE id=?').run(statut, note||'', req.params.id)
  try {
    const { getClient } = require('../../bot/client')
    const client = getClient()
    const { EmbedBuilder } = require('discord.js')
    const chId = cfg('channel_cv')
    if (client?.isReady() && chId) {
      const ch = client.channels.cache.get(chId)
      if (ch) await ch.send({ embeds:[new EmbedBuilder()
        .setColor(statut==='accepte'?0x22c55e:0xef4444)
        .setTitle(statut==='accepte'?'✅ CV Accepté':'❌ CV Refusé')
        .setDescription(`Candidature de **${cv.discord_tag}** : ${statut==='accepte'?'acceptée':'refusée'}`)
        .addFields({name:'Note patron',value:note||'—'}).setTimestamp()
      ]})
      if (statut==='accepte') {
        const rId = cfg('role_attente_entretien')
        if (rId) client.guilds.cache.get(cfg('guild_id'))?.members.fetch(cv.discord_id).then(m=>m.roles.add(rId)).catch(()=>{})
      }
    }
  } catch {}
  res.json({ok:true})
})

// ── ABSENCES ──────────────────────────────────────────────────
router.get('/absences', requirePatron, (req,res) => {
  res.json(db.prepare('SELECT a.*,e.discord_tag,e.grade FROM absences a JOIN employes e ON a.employe_discord_id=e.discord_id ORDER BY a.id DESC').all())
})
router.put('/absences/:id', requirePatron, async (req,res) => {
  const { statut, note } = req.body
  const abs = db.prepare('SELECT a.*,e.discord_tag,e.grade FROM absences a JOIN employes e ON a.employe_discord_id=e.discord_id WHERE a.id=?').get(req.params.id)
  if (!abs) return res.status(404).json({error:'Introuvable'})
  db.prepare("UPDATE absences SET statut=?,note_patron=?,date_traitement=datetime('now') WHERE id=?").run(statut, note||'', req.params.id)
  try {
    const { getClient } = require('../../bot/client')
    const client = getClient()
    const chId = cfg('channel_absences')
    if (client?.isReady() && chId) {
      const { EmbedBuilder } = require('discord.js')
      const ch = client.channels.cache.get(chId)
      if (ch) await ch.send({ embeds:[new EmbedBuilder()
        .setColor(statut==='accepte'?0x22c55e:0xef4444)
        .setTitle(statut==='accepte'?'✅ Absence acceptée':'❌ Absence refusée')
        .setDescription(`Absence de **${abs.discord_tag}** (${abs.grade})`)
        .addFields(
          {name:'Période',value:`${abs.date_debut} → ${abs.date_fin}`,inline:true},
          {name:'Décision',value:statut==='accepte'?'Acceptée ✅':'Refusée ❌',inline:true},
          {name:'Note patron',value:note||'—'}
        ).setTimestamp()
      ]})
    }
  } catch {}
  res.json({ok:true})
})

// ── PRODUCTIONS ───────────────────────────────────────────────
router.get('/productions', requirePatron, (req,res) => {
  res.json(db.prepare('SELECT p.*,e.discord_tag,e.grade FROM productions p JOIN employes e ON p.employe_discord_id=e.discord_id ORDER BY p.id DESC LIMIT 100').all())
})

// ── ENVOYER RÉCAP DISCORD ─────────────────────────────────────
router.post('/envoyer-recap', requirePatron, async (req,res) => {
  const { message } = req.body
  const chId = cfg('channel_annonces')
  if (!chId) return res.status(400).json({error:'Channel annonces non configuré dans Paramètres'})
  const { getClient } = require('../../bot/client')
  const client = getClient()
  if (!client?.isReady()) return res.status(400).json({error:'Bot non connecté'})
  try {
    const { EmbedBuilder } = require('discord.js')
    const now = new Date().toISOString().slice(0,7)
    const employes = db.prepare("SELECT * FROM employes WHERE actif=1").all()
    const grades   = db.prepare("SELECT * FROM grades ORDER BY ordre").all()
    const couleur  = parseInt((cfg('entreprise_couleur')||'#C9A84C').replace('#',''),16)
    const embed = new EmbedBuilder()
      .setColor(couleur)
      .setTitle(`${cfg('entreprise_emoji')||'🍽️'} Récap paie — ${cfg('entreprise_nom')}`)
      .setDescription(message || 'Récapitulatif des paiements.')
      .setTimestamp()
      .setFooter({text:cfg('entreprise_nom')})
    for (const emp of employes) {
      const grade  = grades.find(g=>g.nom===emp.grade) || grades[0] || {}
      const ca     = db.prepare("SELECT COALESCE(SUM(prix),0) as s FROM productions WHERE employe_discord_id=? AND type='vente' AND date LIKE ?").get(emp.discord_id,`${now}%`).s
      const prods  = db.prepare("SELECT COUNT(*) as c FROM productions WHERE employe_discord_id=? AND type='prod' AND date LIKE ?").get(emp.discord_id,`${now}%`).c
      const ventes = db.prepare("SELECT COUNT(*) as c FROM productions WHERE employe_discord_id=? AND type='vente' AND date LIKE ?").get(emp.discord_id,`${now}%`).c
      const heures = db.prepare("SELECT COALESCE(SUM(duree_minutes),0) as s FROM sessions_service WHERE employe_discord_id=? AND date LIKE ?").get(emp.discord_id,`${now}%`).s / 60
      const paye = grade.mode_paye==='piece'
        ? (prods+ventes)*(grade.prix_piece||0)
        : (ca*(grade.taux_base||0)/100)+(prods*(grade.bonus_prod||0))+(ventes*(grade.bonus_vente||0))+(heures*(grade.bonus_heure||0))+(heures*Number(cfg('base_heures')||50))
      embed.addFields({name:`${grade.emoji||'⭐'} ${emp.discord_tag} — ${emp.grade}`,value:`Paie : **$${Math.round(paye).toLocaleString('fr-FR')}**`,inline:false})
    }
    await client.channels.cache.get(chId)?.send({embeds:[embed]})
    res.json({ok:true})
  } catch(err) { res.status(500).json({error:err.message}) }
})

// Uploads
router.use('/uploads', express.static(uploadsDir))
module.exports = router
