/**
 * COLLE CE FICHIER dans bella-cucina-bot/src/web/
 * Puis dans server.js : require('./maintenance') juste avant les routes
 *
 * Usage dans server.js :
 *   const maintenance = require('./maintenance')
 *   app.use(maintenance)
 */

const SHOWROOM_URL = process.env.SHOWROOM_URL
const GUILD_ID     = process.env.GUILD_ID
const CACHE_TTL    = 10_000 // 10s de cache pour ne pas spammer le showroom

let _cache = null
let _cacheAt = 0

async function fetchMaintenanceStatus() {
  if (!SHOWROOM_URL || !GUILD_ID) return false
  if (Date.now() - _cacheAt < CACHE_TTL && _cache !== null) return _cache

  try {
    const res = await fetch(`${SHOWROOM_URL}/api/public/maintenance/${GUILD_ID}`, {
      signal: AbortSignal.timeout(2500),
    })
    const data = await res.json()
    _cache   = data
    _cacheAt = Date.now()
    return data
  } catch {
    return _cache || { maintenance: false }
  }
}

function maintenancePage(data) {
  const cfg = require('../db/database').prepare('SELECT key,value FROM config').all()
  const config = Object.fromEntries(cfg.map(r => [r.key, r.value]))
  const nom   = data.nom   || config.entreprise_nom   || 'Entreprise RP'
  const emoji = data.emoji || config.entreprise_emoji || '🔧'

  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nom} — Maintenance</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      background: #08090c;
      background-image:
        radial-gradient(ellipse 60% 40% at 30% 20%, rgba(250,204,21,0.05) 0%, transparent 70%),
        radial-gradient(ellipse 50% 35% at 75% 80%, rgba(250,204,21,0.03) 0%, transparent 70%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'Segoe UI', sans-serif;
      color: #e8eaf0;
      padding: 20px;
    }
    .card {
      background: #141720;
      border: 0.5px solid rgba(250,204,21,0.2);
      border-radius: 24px;
      padding: 52px 44px;
      text-align: center;
      max-width: 460px;
      width: 100%;
      box-shadow: 0 32px 80px rgba(0,0,0,0.6);
    }
    .icon {
      font-size: 56px;
      display: block;
      margin-bottom: 22px;
      animation: float 3s ease-in-out infinite;
    }
    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50%       { transform: translateY(-10px); }
    }
    .nom {
      font-size: 13px;
      color: #7a7f96;
      text-transform: uppercase;
      letter-spacing: .1em;
      margin-bottom: 10px;
    }
    h1 {
      font-size: 24px;
      font-weight: 700;
      color: #facc15;
      letter-spacing: -.3px;
      margin-bottom: 14px;
    }
    p {
      color: #9ca3af;
      font-size: 15px;
      line-height: 1.75;
      max-width: 320px;
      margin: 0 auto;
    }
    .divider {
      height: 1px;
      background: rgba(255,255,255,0.06);
      margin: 24px 0;
    }
    .since {
      font-size: 12px;
      color: #3d4260;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
    }
    .dot {
      width: 6px; height: 6px;
      border-radius: 50%;
      background: #facc15;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50%       { opacity: .3; }
    }
  </style>
</head>
<body>
  <div class="card">
    <span class="icon">${emoji}</span>
    <div class="nom">${nom}</div>
    <h1>Site en maintenance</h1>
    <p>${data.message || 'Nous effectuons une maintenance. Le site sera de retour très bientôt.'}</p>
    ${data.depuis ? `
      <div class="divider"></div>
      <div class="since">
        <div class="dot"></div>
        Maintenance en cours depuis le ${new Date(data.depuis).toLocaleString('fr-FR')}
      </div>` : ''}
  </div>
</body>
</html>`
}

// ── Middleware Express ─────────────────────────────────────────
module.exports = async function maintenanceMiddleware(req, res, next) {
  // Laisser passer : API, assets statiques, uploads
  if (
    req.path.startsWith('/api') ||
    req.path.startsWith('/uploads') ||
    req.path.match(/\.(css|js|ico|png|jpg|webp|svg|woff2?)$/)
  ) return next()

  const data = await fetchMaintenanceStatus()
  if (data?.maintenance) {
    return res.status(503).send(maintenancePage(data))
  }
  next()
}
