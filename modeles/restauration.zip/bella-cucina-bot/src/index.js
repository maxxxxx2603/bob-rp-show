require('dotenv').config()
const { startWeb } = require('./web/server')

console.log('🍽️ Bella Cucina Bot — Démarrage…')
startWeb()

// Boot auto si token déjà configuré
setTimeout(async () => {
  const { cfg } = require('./db/database')
  const token = cfg('discord_token')
  if (token) {
    console.log('🔄 Token trouvé en DB — connexion automatique…')
    const { startBot } = require('./bot/client')
    const r = await startBot()
    if (r.ok) console.log(`✅ Bot auto-connecté : ${r.tag}`)
    else console.log(`❌ Échec auto-connect : ${r.error}`)
  } else {
    console.log('ℹ️ Aucun token — configure depuis le site patron.')
  }
}, 2000)
