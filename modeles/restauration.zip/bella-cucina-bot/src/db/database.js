const Database = require('better-sqlite3')
const path = require('path')
const fs   = require('fs')

const dataDir    = path.join(process.cwd(), 'data')
const uploadsDir = path.join(dataDir, 'uploads')
if (!fs.existsSync(dataDir))    fs.mkdirSync(dataDir,    { recursive: true })
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true })

const db = new Database(path.join(dataDir, 'bella.db'))
db.pragma('journal_mode = WAL')
db.pragma('foreign_keys = ON')

db.exec(`
  CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS employes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id TEXT UNIQUE NOT NULL,
    discord_tag TEXT NOT NULL,
    grade TEXT DEFAULT 'Employé',
    grade_couleur TEXT DEFAULT '#c9a84c',
    roles_json TEXT DEFAULT '[]',
    discord_avatar TEXT DEFAULT '',
    avatar_initiales TEXT DEFAULT '',
    date_embauche TEXT DEFAULT (date('now')),
    actif INTEGER DEFAULT 1,
    password_hash TEXT,
    first_login INTEGER DEFAULT 1,
    slug TEXT UNIQUE
  );

  CREATE TABLE IF NOT EXISTS sessions_service (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_discord_id TEXT NOT NULL,
    debut TEXT NOT NULL,
    fin TEXT,
    duree_minutes INTEGER,
    date TEXT DEFAULT (date('now'))
  );

  CREATE TABLE IF NOT EXISTS cv (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id TEXT NOT NULL,
    discord_tag TEXT NOT NULL,
    reponses TEXT NOT NULL,
    statut TEXT DEFAULT 'en_attente',
    date_soumission TEXT DEFAULT (datetime('now')),
    note_patron TEXT
  );

  CREATE TABLE IF NOT EXISTS productions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_discord_id TEXT NOT NULL,
    type TEXT NOT NULL,
    article TEXT NOT NULL,
    quantite INTEGER NOT NULL,
    prix REAL DEFAULT 0,
    preuve_filename TEXT,
    date TEXT DEFAULT (datetime('now')),
    valide INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS absences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_discord_id TEXT NOT NULL,
    date_debut TEXT NOT NULL,
    date_fin TEXT NOT NULL,
    raison TEXT DEFAULT '',
    statut TEXT DEFAULT 'en_attente',
    note_patron TEXT DEFAULT '',
    date_declaration TEXT DEFAULT (datetime('now')),
    date_traitement TEXT
  );

  CREATE TABLE IF NOT EXISTS avertissements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employe_discord_id TEXT NOT NULL,
    message TEXT NOT NULL,
    date TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS grades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT UNIQUE NOT NULL,
    couleur TEXT DEFAULT '#c9a84c',
    emoji TEXT DEFAULT '⭐',
    ordre INTEGER DEFAULT 0,
    mode_paye TEXT DEFAULT 'pourcentage',
    taux_base REAL DEFAULT 5,
    bonus_prod REAL DEFAULT 1,
    bonus_vente REAL DEFAULT 2,
    bonus_heure REAL DEFAULT 0.5,
    prix_piece REAL DEFAULT 150,
    role_discord TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS questions_cv (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ordre INTEGER NOT NULL,
    question TEXT NOT NULL,
    actif INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT UNIQUE NOT NULL,
    actif INTEGER DEFAULT 1
  );
`)

// Config par défaut — tout vide, le patron remplit depuis le site
const ic = db.prepare('INSERT OR IGNORE INTO config (key,value) VALUES (?,?)')
const DEFAULTS = {
  entreprise_nom:      'Mon Entreprise RP',
  entreprise_couleur:  '#C9A84C',
  entreprise_emoji:    '🍽️',
  discord_token:       '',
  discord_client_id:   '',
  guild_id:            '',
  channel_cv:          '',
  channel_logs:        '',
  channel_productions: '',
  channel_ventes:      '',
  channel_alertes:     '',
  channel_welcome:     '',
  channel_annonces:    '',
  channel_absences:    '',
  role_employe:        '',
  role_attente_entretien: '',
  role_patron:         '',
  base_heures:         '50',
  bot_actif:           '0',
}
for (const [k,v] of Object.entries(DEFAULTS)) ic.run(k,v)

// Grades par défaut
if (db.prepare('SELECT COUNT(*) as c FROM grades').get().c === 0) {
  const ig = db.prepare('INSERT OR IGNORE INTO grades (nom,couleur,emoji,ordre,taux_base,bonus_prod,bonus_vente,bonus_heure,prix_piece) VALUES (?,?,?,?,?,?,?,?,?)')
  ;[
    ['Stagiaire',   '#6b7280','🔰',0, 3,  0.5,1,  0.2,100],
    ['Employé',     '#60a5fa','👤',1, 5,  1,  2,  0.5,150],
    ['Senior',      '#a78bfa','⭐',2, 8,  1.5,3,  0.8,200],
    ['Chef de rang','#f59e0b','🍴',3, 10, 2,  4,  1,  280],
    ['Manager',     '#c9a84c','👑',4, 12, 2.5,5,  1.2,350],
    ['Directeur',   '#ef4444','💎',5, 15, 3,  6,  1.5,500],
  ].forEach(r => ig.run(...r))
}

if (db.prepare('SELECT COUNT(*) as c FROM questions_cv').get().c === 0) {
  const iq = db.prepare('INSERT INTO questions_cv (ordre,question) VALUES (?,?)')
  ;["Quel poste vous intéresse ?","Avez-vous de l'expérience RP en restauration ?","Quelles sont vos disponibilités en jeu ?","Décrivez-vous en 3 mots","Pourquoi rejoindre notre entreprise ?"]
    .forEach((q,i) => iq.run(i+1,q))
}

if (db.prepare('SELECT COUNT(*) as c FROM articles').get().c === 0) {
  const ia = db.prepare('INSERT OR IGNORE INTO articles (nom) VALUES (?)')
  ;['Burger RP x1','Pizza Margherita','Frites Large','Soda Cola 6pack','Café Espresso','Menu Enfant','Salade Caesar']
    .forEach(a => ia.run(a))
}

function cfg(k) { return db.prepare('SELECT value FROM config WHERE key=?').get(k)?.value || '' }
function setCfg(k,v) { db.prepare('INSERT OR REPLACE INTO config (key,value) VALUES (?,?)').run(k, String(v||'')) }

module.exports = { db, uploadsDir, cfg, setCfg }
